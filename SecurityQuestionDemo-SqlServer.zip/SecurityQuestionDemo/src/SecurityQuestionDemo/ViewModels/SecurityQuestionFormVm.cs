using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace SecurityQuestionDemo.ViewModels;

public sealed class SecurityQuestionItemVm
{
    [Required(ErrorMessage = "請選擇安全問題")]
    public int? QuestionId { get; set; }

    [Required(ErrorMessage = "請輸入答案")]
    [StringLength(200, ErrorMessage = "答案長度不得超過 200 個字")]
    public string Answer { get; set; } = string.Empty;
}

public sealed class SecurityQuestionFormVm
{
    public List<SecurityQuestionItemVm> Items { get; set; }
        = Enumerable.Range(0, 3)
            .Select(_ => new SecurityQuestionItemVm())
            .ToList();

    [BindNever]
    public IReadOnlyList<SelectListItem> QuestionOptions { get; set; }
        = Array.Empty<SelectListItem>();
}
