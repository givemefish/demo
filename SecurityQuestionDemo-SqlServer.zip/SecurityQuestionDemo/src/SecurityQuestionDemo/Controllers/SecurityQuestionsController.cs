using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SecurityQuestionDemo.Data;
using SecurityQuestionDemo.Models;
using SecurityQuestionDemo.ViewModels;

namespace SecurityQuestionDemo.Controllers;

[Route("security-questions")]
public sealed class SecurityQuestionsController : Controller
{
    // 雛型未整合登入；正式系統應改用使用者 Claim 或 Identity UserId。
    private const string DemoUserId = "demo-user";

    private readonly AppDbContext _db;
    private readonly IPasswordHasher<UserSecurityAnswer> _answerHasher;
    private readonly ILogger<SecurityQuestionsController> _logger;

    public SecurityQuestionsController(
        AppDbContext db,
        IPasswordHasher<UserSecurityAnswer> answerHasher,
        ILogger<SecurityQuestionsController> logger)
    {
        _db = db;
        _answerHasher = answerHasher;
        _logger = logger;
    }

    [HttpGet("")]
    public async Task<IActionResult> Index(CancellationToken cancellationToken)
    {
        var existingItems = await _db.UserSecurityAnswers
            .AsNoTracking()
            .Where(x => x.UserId == DemoUserId)
            .OrderBy(x => x.Position)
            .Select(x => new SecurityQuestionItemVm
            {
                QuestionId = x.SecurityQuestionId,
                // 答案只保存 Hash，編輯時要求重新輸入。
                Answer = string.Empty
            })
            .Take(3)
            .ToListAsync(cancellationToken);

        EnsureThreeItems(existingItems);

        var vm = new SecurityQuestionFormVm
        {
            Items = existingItems
        };

        await PopulateQuestionOptionsAsync(vm, cancellationToken);
        return View(vm);
    }

    [HttpPost("")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(
        SecurityQuestionFormVm vm,
        CancellationToken cancellationToken)
    {
        vm.Items ??= new List<SecurityQuestionItemVm>();

        if (vm.Items.Count != 3)
        {
            ModelState.AddModelError(string.Empty, "必須設定三個安全問題。");
            EnsureThreeItems(vm.Items);
        }
        else
        {
            ValidateDuplicateQuestions(vm);
            await ValidateQuestionIdsAsync(vm, cancellationToken);
        }

        if (!ModelState.IsValid)
        {
            await PopulateQuestionOptionsAsync(vm, cancellationToken);
            return View(vm);
        }

        await using var transaction =
            await _db.Database.BeginTransactionAsync(cancellationToken);

        try
        {
            var existingAnswers = await _db.UserSecurityAnswers
                .Where(x => x.UserId == DemoUserId)
                .ToListAsync(cancellationToken);

            if (existingAnswers.Count > 0)
            {
                _db.UserSecurityAnswers.RemoveRange(existingAnswers);
                await _db.SaveChangesAsync(cancellationToken);
            }

            var newAnswers = vm.Items
                .Select((item, index) =>
                {
                    var entity = new UserSecurityAnswer
                    {
                        UserId = DemoUserId,
                        Position = index + 1,
                        SecurityQuestionId = item.QuestionId!.Value
                    };

                    entity.AnswerHash = _answerHasher.HashPassword(
                        entity,
                        NormalizeAnswer(item.Answer));

                    return entity;
                })
                .ToList();

            await _db.UserSecurityAnswers.AddRangeAsync(
                newAnswers,
                cancellationToken);

            await _db.SaveChangesAsync(cancellationToken);
            await transaction.CommitAsync(cancellationToken);

            TempData["SuccessMessage"] = "安全問題已成功儲存。";
            return RedirectToAction(nameof(Index));
        }
        catch (DbUpdateException exception)
        {
            await transaction.RollbackAsync(cancellationToken);

            _logger.LogError(
                exception,
                "儲存使用者 {UserId} 的安全問題失敗。",
                DemoUserId);

            ModelState.AddModelError(
                string.Empty,
                "安全問題儲存失敗，資料可能已被其他要求修改，請重新選擇後再試。");

            await PopulateQuestionOptionsAsync(vm, cancellationToken);
            return View(vm);
        }
    }

    private async Task PopulateQuestionOptionsAsync(
        SecurityQuestionFormVm vm,
        CancellationToken cancellationToken)
    {
        vm.QuestionOptions = await _db.SecurityQuestions
            .AsNoTracking()
            .Where(x => x.IsActive)
            .OrderBy(x => x.SortOrder)
            .ThenBy(x => x.Id)
            .Select(x => new SelectListItem
            {
                Value = x.Id.ToString(),
                Text = x.QuestionText
            })
            .ToListAsync(cancellationToken);
    }

    private static void ValidateDuplicateQuestions(SecurityQuestionFormVm vm)
    {
        var duplicateGroups = vm.Items
            .Select((item, index) => new { Item = item, Index = index })
            .Where(x => x.Item.QuestionId.HasValue)
            .GroupBy(x => x.Item.QuestionId!.Value)
            .Where(group => group.Count() > 1);

        foreach (var group in duplicateGroups)
        {
            // 第一個欄位保留；第二個之後標示為重複。
            foreach (var duplicate in group.Skip(1))
            {
                ModelState.AddModelError(
                    $"Items[{duplicate.Index}].QuestionId",
                    "問題已被選擇，請選其他題");
            }
        }
    }

    private async Task ValidateQuestionIdsAsync(
        SecurityQuestionFormVm vm,
        CancellationToken cancellationToken)
    {
        var submittedIds = vm.Items
            .Where(x => x.QuestionId.HasValue)
            .Select(x => x.QuestionId!.Value)
            .Distinct()
            .ToList();

        var validIds = await _db.SecurityQuestions
            .AsNoTracking()
            .Where(x => x.IsActive && submittedIds.Contains(x.Id))
            .Select(x => x.Id)
            .ToHashSetAsync(cancellationToken);

        for (var index = 0; index < vm.Items.Count; index++)
        {
            var questionId = vm.Items[index].QuestionId;

            if (questionId.HasValue && !validIds.Contains(questionId.Value))
            {
                ModelState.AddModelError(
                    $"Items[{index}].QuestionId",
                    "選擇的問題不存在或已停用。");
            }
        }
    }

    private static void EnsureThreeItems(List<SecurityQuestionItemVm> items)
    {
        if (items.Count > 3)
        {
            items.RemoveRange(3, items.Count - 3);
        }

        while (items.Count < 3)
        {
            items.Add(new SecurityQuestionItemVm());
        }
    }

    private static string NormalizeAnswer(string answer)
    {
        return answer
            .Trim()
            .Normalize(NormalizationForm.FormKC)
            .ToUpperInvariant();
    }
}
