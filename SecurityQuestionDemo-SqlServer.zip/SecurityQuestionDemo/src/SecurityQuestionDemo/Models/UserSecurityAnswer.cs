using System.ComponentModel.DataAnnotations;

namespace SecurityQuestionDemo.Models;

public sealed class UserSecurityAnswer
{
    public long Id { get; set; }

    [Required]
    [MaxLength(450)]
    public string UserId { get; set; } = string.Empty;

    /// <summary>
    /// 顯示位置，只允許 1、2、3。
    /// </summary>
    public int Position { get; set; }

    public int SecurityQuestionId { get; set; }

    [Required]
    [MaxLength(500)]
    public string AnswerHash { get; set; } = string.Empty;

    public SecurityQuestion? SecurityQuestion { get; set; }
}
