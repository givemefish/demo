using System.ComponentModel.DataAnnotations;

namespace SecurityQuestionDemo.Models;

public sealed class SecurityQuestion
{
    public int Id { get; set; }

    [Required]
    [MaxLength(300)]
    public string QuestionText { get; set; } = string.Empty;

    public bool IsActive { get; set; } = true;

    public int SortOrder { get; set; }

    public ICollection<UserSecurityAnswer> UserAnswers { get; set; }
        = new List<UserSecurityAnswer>();
}
