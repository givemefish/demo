using Microsoft.EntityFrameworkCore;
using SecurityQuestionDemo.Models;

namespace SecurityQuestionDemo.Data;

public static class DbInitializer
{
    public static async Task InitializeAsync(
        AppDbContext db,
        ILogger logger,
        CancellationToken cancellationToken = default)
    {
        const int maxAttempts = 12;
        var delay = TimeSpan.FromSeconds(5);

        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            try
            {
                await db.Database.EnsureCreatedAsync(cancellationToken);
                break;
            }
            catch (Exception exception) when (attempt < maxAttempts)
            {
                logger.LogWarning(
                    exception,
                    "SQL Server 尚未可用，{DelaySeconds} 秒後重試（{Attempt}/{MaxAttempts}）。",
                    delay.TotalSeconds,
                    attempt,
                    maxAttempts);

                await Task.Delay(delay, cancellationToken);
            }
        }

        if (await db.SecurityQuestions.AnyAsync(cancellationToken))
        {
            return;
        }

        var questions = new[]
        {
            new SecurityQuestion
            {
                QuestionText = "When is your father's birthday? (DDMM)",
                SortOrder = 1
            },
            new SecurityQuestion
            {
                QuestionText = "When is your mother's birthday? (DDMM)",
                SortOrder = 2
            },
            new SecurityQuestion
            {
                QuestionText = "What is your favourite city?",
                SortOrder = 3
            },
            new SecurityQuestion
            {
                QuestionText = "What is your favourite sport?",
                SortOrder = 4
            },
            new SecurityQuestion
            {
                QuestionText = "What is the subject that you hate the most at school?",
                SortOrder = 5
            },
            new SecurityQuestion
            {
                QuestionText = "Where in the world would you most like to visit?",
                SortOrder = 6
            },
            new SecurityQuestion
            {
                QuestionText = "Who was your best childhood friend?",
                SortOrder = 7
            }
        };

        await db.SecurityQuestions.AddRangeAsync(questions, cancellationToken);
        await db.SaveChangesAsync(cancellationToken);

        logger.LogInformation("已建立安全問題範例資料，共 {Count} 筆。", questions.Length);
    }
}
