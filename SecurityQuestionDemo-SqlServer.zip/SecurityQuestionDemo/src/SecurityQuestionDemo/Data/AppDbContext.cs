using Microsoft.EntityFrameworkCore;
using SecurityQuestionDemo.Models;

namespace SecurityQuestionDemo.Data;

public sealed class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }

    public DbSet<SecurityQuestion> SecurityQuestions => Set<SecurityQuestion>();

    public DbSet<UserSecurityAnswer> UserSecurityAnswers => Set<UserSecurityAnswer>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<SecurityQuestion>(entity =>
        {
            entity.ToTable("SecurityQuestion");

            entity.Property(x => x.QuestionText)
                .HasMaxLength(300)
                .IsRequired();

            entity.HasIndex(x => new { x.IsActive, x.SortOrder });
        });

        modelBuilder.Entity<UserSecurityAnswer>(entity =>
        {
            entity.ToTable("UserSecurityAnswer");

            entity.Property(x => x.UserId)
                .HasMaxLength(450)
                .IsRequired();

            entity.Property(x => x.AnswerHash)
                .HasMaxLength(500)
                .IsRequired();

            // 同一使用者的 1、2、3 位置各只能有一筆。
            entity.HasIndex(x => new { x.UserId, x.Position })
                .IsUnique();

            // 同一使用者不能在不同位置選擇同一題。
            entity.HasIndex(x => new { x.UserId, x.SecurityQuestionId })
                .IsUnique();

            entity.ToTable(table =>
                table.HasCheckConstraint(
                    "CK_UserSecurityAnswer_Position",
                    "[Position] >= 1 AND [Position] <= 3"));

            entity.HasOne(x => x.SecurityQuestion)
                .WithMany(x => x.UserAnswers)
                .HasForeignKey(x => x.SecurityQuestionId)
                .OnDelete(DeleteBehavior.Restrict);
        });
    }
}
