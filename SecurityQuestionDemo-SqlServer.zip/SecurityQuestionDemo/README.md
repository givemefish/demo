# Security Question MVC Demo

這是一個可直接改造的雛型，示範 **ASP.NET Core MVC + jQuery + Entity Framework Core + SQL Server** 的三組安全問題表單。

## 功能

- 七個問題由 SQL Server 資料庫讀取。
- 頁面呈現三組「問題 + 答案」。
- jQuery 在選到重複問題時顯示：`問題已被選擇，請選其他題`，並恢復原值。
- Form POST 後，伺服器再次驗證：
  - 必須恰好提交三組資料。
  - 三題不得重複。
  - QuestionId 必須存在且為啟用狀態。
- SQL Server 唯一索引防止同一使用者重複選題。
- 答案經 Unicode 正規化後，以 ASP.NET Core `PasswordHasher` 雜湊，不保存明文。
- 成功儲存後採用 PRG（Post/Redirect/Get），避免重新整理造成重複送出。

## 技術

- .NET 8
- ASP.NET Core MVC
- Entity Framework Core 8
- SQL Server 2022
- jQuery 3.7
- Bootstrap 5

## 專案結構

```text
SecurityQuestionDemo.sln
src/SecurityQuestionDemo/
├─ Controllers/SecurityQuestionsController.cs
├─ Data/AppDbContext.cs
├─ Data/DbInitializer.cs
├─ Models/SecurityQuestion.cs
├─ Models/UserSecurityAnswer.cs
├─ ViewModels/SecurityQuestionFormVm.cs
├─ Views/SecurityQuestions/Index.cshtml
├─ Views/Shared/_Layout.cshtml
├─ Program.cs
├─ appsettings.json
└─ SecurityQuestionDemo.csproj
```

## 快速啟動

### 1. 啟動 SQL Server

專案附有 Docker Compose：

```bash
docker compose up -d
```

預設只供本機開發使用：

```text
Server: localhost,1433
User: sa
Password: DevOnly_StrongPassword!123
Database: SecurityQuestionDemo
```

> 此密碼僅供範例。正式環境必須使用 Secret Manager、環境變數、Key Vault 或其他祕密管理機制。

也可以改用既有的 SQL Server，修改：

```text
src/SecurityQuestionDemo/appsettings.Development.json
```

### 2. 執行網站

```bash
dotnet restore
dotnet run --project src/SecurityQuestionDemo
```

開啟終端機顯示的網址，預設首頁即為安全問題頁面，也可直接進入：

```text
/security-questions
```

啟動時 `DbInitializer` 會：

1. 等待 SQL Server 可連線。
2. 以 `EnsureCreatedAsync()` 建立資料表。
3. 加入七筆範例問題。

## 正式環境建議改用 Migration

雛型為了容易執行，使用 `EnsureCreatedAsync()`。正式環境應改用 EF Core Migration 管理 schema 版本。

安裝 EF CLI：

```bash
dotnet tool install --global dotnet-ef
```

建立 Migration：

```bash
dotnet ef migrations add InitialCreate \
  --project src/SecurityQuestionDemo \
  --startup-project src/SecurityQuestionDemo
```

套用 Migration：

```bash
dotnet ef database update \
  --project src/SecurityQuestionDemo \
  --startup-project src/SecurityQuestionDemo
```

改用 Migration 後，請將 `Program.cs` 中的 `DbInitializer.InitializeAsync(...)` 調整為只負責 seed，或移除 `EnsureCreatedAsync()`。

## 使用者身分

此雛型沒有加入登入流程，Controller 暫時使用固定值：

```csharp
private const string DemoUserId = "demo-user";
```

整合 ASP.NET Core Identity 或既有 SSO 後，應改為：

```csharp
User.FindFirstValue(ClaimTypes.NameIdentifier)
```

並在 Controller 加上 `[Authorize]`。

## 連線字串覆寫

不要把正式帳密寫入 Git。可使用環境變數：

### Windows PowerShell

```powershell
$env:ConnectionStrings__DefaultConnection = "Server=...;Database=...;User Id=...;Password=...;TrustServerCertificate=True"
dotnet run --project src/SecurityQuestionDemo
```

### Linux / macOS

```bash
export ConnectionStrings__DefaultConnection='Server=...;Database=...;User Id=...;Password=...;TrustServerCertificate=True'
dotnet run --project src/SecurityQuestionDemo
```

## 安全注意事項

安全問題本身不是高強度認證因素。正式系統至少還應考慮：

- 登入或重設密碼時的嘗試次數限制。
- 稽核日誌，但不得記錄答案明文。
- MFA 或 Passkey 作為主要驗證方式。
- 明確定義答案比較規則，例如是否忽略大小寫及全半形差異。
- 資料庫帳號最小權限與正式環境的加密連線。
